<?php

return [
    'name' => 'Superadmin',
    'module_version' => '6.2',
    'pid' => 20
];
